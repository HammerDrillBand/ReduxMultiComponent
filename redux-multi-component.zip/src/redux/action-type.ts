export enum ActionType {
    UserEnteredNumbers
}
