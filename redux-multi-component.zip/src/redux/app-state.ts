export class AppState {
    public number1: number = 0;
    public number2: number = 0;
}